                                                                    TABLES


1. hotels 

| hotels | CREATE TABLE `hotels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `city` varchar(25) NOT NULL,
  `totalRooms` int(11) NOT NULL,
  `starRating` double DEFAULT NULL,
  `tarrifPerDay` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 |



2. hotelbooking


| hotelbooking | CREATE TABLE `hotelbooking` (
  `bookingId` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(25) NOT NULL,
  `hotel` varchar(25) NOT NULL,
  `fromDate` date NOT NULL,
  `toDate` date NOT NULL,
  `numberOfRooms` int(11) NOT NULL DEFAULT '0',
  `hotelId` int(11) DEFAULT NULL,
  `customerName` varchar(45) NOT NULL DEFAULT '',
  `totalPrice` int(10) unsigned NOT NULL DEFAULT '0',
  `numberOfDays` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bookingId`),
  KEY `FK_hotelbookinghid_hotelsid` (`hotelId`),
  CONSTRAINT `FK_hotelbookinghid_hotelsid` FOREIGN KEY (`hotelId`) REFERENCES `h
otels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 |

----------------------------------------------------------------------------------------------------------------------------------------------

								STORED PROCEDURES


1. RoomChecker1


DELIMITER $$

DROP PROCEDURE IF EXISTS `hotelmanagement`.`RoomChecker1` $$
CREATE PROCEDURE `hotelmanagement`.`RoomChecker1` (in from_date date,in to_date date,in hotel_id int,in needed_rooms int,out booleanval int)
BEGIN
declare booked int;
declare total int;
declare available int;
declare sc int;
declare booli int;
declare test int;
set booli=0;
set test=0;
while (from_date <= to_date) do
set booked = (select sum(numberOfRooms) from hotelbooking where from_date between fromdate and todate and hotelid=hotel_id);
if booked is null then
set sc=1;
else
set sc=0;
end if;
set total=(select totalrooms from hotels where id=hotel_id);
set available=total-booked;
if ((available >= needed_rooms) or (sc and (needed_rooms <= total))) then
set booli=booli+1;
else
set booli=0;
end if;
set from_date=(select date_add(from_date,Interval 1 day));
set test=test+1;
end while;
if (booli = test) then
set booleanval=1;
else
set booleanval=0;
end if;
END $$

DELIMITER ;




2. RoomChecker2

DELIMITER $$

DROP PROCEDURE IF EXISTS `hotelmanagement`.`RoomChecker2` $$
CREATE PROCEDURE `hotelmanagement`.`RoomChecker2` (in fromdate date,in todate date,in hotel_id int,in needed_rooms int)
BEGIN
call RoomChecker1 (fromdate,todate,hotel_id,needed_rooms,@booleanval);
select @booleanval;
END $$

DELIMITER ;
