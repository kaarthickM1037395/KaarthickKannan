package com.mindtree.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hotels")
public class Hotel {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;
	private String city;
	private String totalRooms;
	private String starRating;
	private int tarrifPerDay;

	public int getTarrifPerDay() {
		return tarrifPerDay;
	}
	public void setTarrifPerDay(int tarrifPerDay) {
		this.tarrifPerDay = tarrifPerDay;
	}
	public String getTotalRooms() {
		return totalRooms;
	}
	public void setTotalRooms(String totalRooms) {
		this.totalRooms = totalRooms;
	}
	
	public String getName() {
		return name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public String getStarRating() {
		return starRating;
	}
	public void setStarRating(String starRating) {
		this.starRating = starRating;
	}
	
	@Override
	public String toString() {
		return "Hotel [id=" + id + ", name=" + name + ", city=" + city + ", totalRooms=" + totalRooms
				+ ", starRating=" + starRating + ", tarrifPerDay=" + tarrifPerDay + "]";
	}


}
