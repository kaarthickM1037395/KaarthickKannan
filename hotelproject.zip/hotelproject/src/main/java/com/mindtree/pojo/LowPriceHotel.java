package com.mindtree.pojo;

public class LowPriceHotel {
	private String cityOfHotel;
	private String nameOfHotel;
	public String getCityOfHotel() {
		return cityOfHotel;
	}
	public void setCityOfHotel(String cityOfHotel) {
		this.cityOfHotel = cityOfHotel;
	}
	public String getNameOfHotel() {
		return nameOfHotel;
	}
	public void setNameOfHotel(String nameOfHotel) {
		this.nameOfHotel = nameOfHotel;
	}

}
