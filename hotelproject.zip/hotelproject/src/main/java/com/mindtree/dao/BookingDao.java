package com.mindtree.dao;

import java.util.Date;
import java.util.List;

import com.mindtree.pojo.BookingDetails;
import com.mindtree.pojo.Hotel;

public interface BookingDao {



	public List<String> listCities();

	public String listHotels(String selectedName);


	public void booked(BookingDetails book);
	
	public String listHotelsAsc(String cit);

	public Integer gettingHotedId(String dataincity, String datainhotel);

	public Integer callStoredProcedure(Date fromDate, Date toDate, String bookedHotelId, int neededRooms);

	public Integer gettingPricePerHotel(String dataincity, String datainhotel);

}
