package com.mindtree.dao;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.pojo.BookingDetails;
import com.mindtree.pojo.Hotel;

@Repository
public class BookingDaoImpl implements BookingDao {

	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	@Transactional
	public List<String> listCities() {

		Session session = this.sessionFactory.getCurrentSession();
		List<String> citiesList = session.createSQLQuery("select distinct city from hotels").list();
		for (String c : citiesList) {

		}
		return citiesList;
	}

	@Override
	@Transactional
	public String listHotels(String selectedName) {
		// TODO Auto-generated method stub

		Session session = this.sessionFactory.getCurrentSession();
		SQLQuery query = session.createSQLQuery("select name from hotels where city = :cName");

		query.setParameter("cName", selectedName);

		List<String> hotelsList = query.list();
		StringBuilder splitting = new StringBuilder();
		for (int i = 0; i < hotelsList.size(); i++) {
			splitting.append(hotelsList.get(i));
			if (i != hotelsList.size() - 1) {
				splitting.append("-");
			}
		}
		System.out.println(splitting.toString());

		return splitting.toString();
	}

	@Override
	@Transactional
	public void booked(BookingDetails book) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(book);

	}

	@Override
	@Transactional
	public String listHotelsAsc(String cit) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		SQLQuery query = session
				.createSQLQuery("select name from hotels  where city = :cName order by tarrifperday asc");
		/* query.addEntity(Hotel.class); */
		query.setParameter("cName", cit);

		// List<Hotel> hotelsList=session.createSQLQuery("select name from
		// hotels where city = :cname").list();
		List<String> hotelsListlow = query.list();
		StringBuilder splittinglow = new StringBuilder();
		for (int i = 0; i < hotelsListlow.size(); i++) {
			splittinglow.append(hotelsListlow.get(i));
			if (i != hotelsListlow.size() - 1) {
				splittinglow.append("+");
			}
		}

		return splittinglow.toString();
	}

	@Override
	@Transactional
	public Integer gettingHotedId(String dataincity, String datainhotel) {
		// TODO Auto-generated method stub

		Session session = this.sessionFactory.getCurrentSession();
		SQLQuery query = session.createSQLQuery("select id from hotels where name = :cName and city = :cCity");
		/* query.addEntity(Hotel.class); */
		query.setParameter("cName", datainhotel);
		query.setParameter("cCity", dataincity);
		int hotelIdRet = (Integer) query.uniqueResult();

		return hotelIdRet;
	}

	@Override
	@Transactional
	public Integer callStoredProcedure(Date fromDate, Date toDate, String bookedHotelId, int neededRooms) {
		Session session = this.sessionFactory.getCurrentSession();
		SQLQuery query = session.createSQLQuery("call RoomChecker2(:one,:two,:three,:four)");
		java.sql.Date sqlDate1 = new java.sql.Date(fromDate.getTime());
		java.sql.Date sqlDate2 = new java.sql.Date(toDate.getTime());

		query.setParameter("one", sqlDate1);
		query.setParameter("two", sqlDate2);
		query.setParameter("three", bookedHotelId);
		query.setParameter("four", neededRooms);
		int op = ((BigInteger) query.uniqueResult()).intValue();

		return op;
	}

	@Override
	@Transactional
	public Integer gettingPricePerHotel(String dataincity, String datainhotel) {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.getCurrentSession();
		SQLQuery query = session.createSQLQuery("select TarrifPerDay from hotels where name = :one and city = :two");
		/* query.addEntity(Hotel.class); */
		query.setParameter("one", datainhotel);
		query.setParameter("two", dataincity);
		int hotelIdRet = (Integer) query.uniqueResult();
		return hotelIdRet;

	}

}
