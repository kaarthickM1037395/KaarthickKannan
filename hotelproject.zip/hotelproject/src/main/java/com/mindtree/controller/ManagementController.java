package com.mindtree.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mindtree.pojo.BookingDetails;
import com.mindtree.pojo.LowPriceHotel;
import com.mindtree.service.BookingService;

@Controller
public class ManagementController {

	private static final Logger logger = Logger.getLogger(ManagementController.class);

	@Autowired
	private BookingService bookingService;

	@RequestMapping(value = "/bookrooms", method = RequestMethod.GET)
	public String bookRoom(Model model) {
		BookingDetails b = new BookingDetails();
		model.addAttribute("booking", b);
		model.addAttribute("listcities", this.bookingService.listCities());
		logger.info("Getting cities list ");
		logger.info("The bookroom view is about to be returned");
		return "bookroom";
	}

	@RequestMapping(value = "/bookrooms", method = RequestMethod.POST)
	public String secondSubmit(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("booking") @Valid BookingDetails book, BindingResult result, Model model,
			final RedirectAttributes redirectAttributes) {

		if (result.hasErrors()) {
			logger.info("The form Inputs are not correct according to validator");
			BookingDetails emptyForm = new BookingDetails();
			BeanUtils.copyProperties(emptyForm, book);
			model.addAttribute("listcities", this.bookingService.listCities());
			logger.info("returning the same bookroom view");
			return "bookroom";
		}

		logger.info("stored procedure about to be called");
		Integer flag = bookingService.callStoredProcedure(book.getFromDate(), book.getToDate(), book.getHotelId(),
				book.getNumberOfRooms());
		logger.info(
				"stored procedure output to check whether the needed amount of rooms is avilable in that particular day has been recieved");

		if (flag == 1) {
			logger.info("Requested amount of rooms are avilable in the given date in the selected hotel");
			redirectAttributes.addFlashAttribute("booking", book);
			return "redirect:/Thankyou";
		} else {
			logger.info("The requested amount of are not available in the given date in the selected hotel");
			BookingDetails emptyForm = new BookingDetails();
			BeanUtils.copyProperties(emptyForm, book);
			model.addAttribute("noRoomsAvailable",
					"SORRY!!! :( NO Requested amount of Rooms available in this hotel for this day, try any other hotel");
			model.addAttribute("listcities", this.bookingService.listCities());
			return "bookroom";
		}

	}

	@ExceptionHandler
	@RequestMapping(value = "/Thankyou", method = RequestMethod.GET)
	public String thankYou(@ModelAttribute("booking") BookingDetails book, Model model) {
	
			bookingService.booked(book);
			logger.info("The Necessary contents are stored in the database");
			java.sql.Date sqlDate1 = new java.sql.Date(book.getFromDate().getTime());
			java.sql.Date sqlDate2 = new java.sql.Date(book.getToDate().getTime());
			book.setFromDate(sqlDate1);
			book.setToDate(sqlDate2);
			ModelMap mod = new ModelMap();
			mod.put("booking", book);
			logger.info("About to return the view of thanks with details");
			return "Thanks";

	}

	@RequestMapping(value = "/viewlow", method = RequestMethod.GET)
	public String viewLow(Model model) {
		LowPriceHotel lh = new LowPriceHotel();
		model.addAttribute("lowprice", lh);
		model.addAttribute("listcities", this.bookingService.listCities());
		logger.info("The list of cities has been returned");
		logger.info("view for checking out for lowest price hotels are about to be sent");
		return "viewfivelow";
	}

	@ResponseBody
	@RequestMapping(value = "/ajaxforgettinghotels")
	public String postingHotels(@RequestParam String cit) {
		logger.info("Hotels list for the selected city is about to be returned");
		return this.bookingService.listHotels(cit);

	}

	@ResponseBody
	@RequestMapping(value = "/ajaxforgettinglowpricehotels")
	public String hotelsInAsc(@RequestParam String citForLow) {
		logger.info("Hotels list in Ascending order for the selected city is about to be returned");
		return this.bookingService.listHotelsAsc(citForLow);
	}

	@ResponseBody
	@RequestMapping(value = "/ajaxforgettinghotelId")
	public String hotelsIdGetting(@RequestParam String dataincity, @RequestParam String datainhotel) {
		String hotelId = this.bookingService.gettingHotedId(dataincity, datainhotel).toString();
		String pricePerHotel = String.valueOf(this.bookingService.gettingPricePerHotel(dataincity, datainhotel));
		String total = hotelId + "-" + pricePerHotel;
		return total;
	}

}
