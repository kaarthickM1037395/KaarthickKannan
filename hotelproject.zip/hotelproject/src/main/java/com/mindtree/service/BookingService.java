package com.mindtree.service;

import java.util.Date;
import java.util.List;

import com.mindtree.pojo.BookingDetails;
import com.mindtree.pojo.Hotel;

public interface BookingService {

	public List<String> listCities();

	public String listHotels(String selectedCity);

	public void booked(BookingDetails book);

	public String listHotelsAsc(String cit);

	public Integer gettingHotedId(String dataincity, String datainhotel);

	public Integer callStoredProcedure(Date fromDate, Date toDate, String bookedHotelId, int neededRooms);

	public Integer gettingPricePerHotel(String dataincity, String datainhotel);



}
