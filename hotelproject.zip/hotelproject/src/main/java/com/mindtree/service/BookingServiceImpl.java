package com.mindtree.service;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.BookingDao;
import com.mindtree.pojo.BookingDetails;
import com.mindtree.pojo.Hotel;

@Service
public class BookingServiceImpl implements BookingService {

	private BookingDao bookingDao;

	@Override
	@Transactional
	public List<String> listCities() {

		return bookingDao.listCities();
	}

	public BookingDao getBookingDao() {
		return bookingDao;
	}

	public void setBookingDao(BookingDao bookingDao) {
		this.bookingDao = bookingDao;
	}

	@Override
	@Transactional
	public String listHotels(String selectedName) {
		// TODO Auto-generated method stub
		return bookingDao.listHotels(selectedName);
	}

	@Override
	@Transactional
	public void booked(BookingDetails book) {
		// TODO Auto-generated method stub
		bookingDao.booked(book);
	}

	@Override
	@Transactional
	public String listHotelsAsc(String cit) {
		// TODO Auto-generated method stub
		return bookingDao.listHotelsAsc(cit);
	}

	@Override
	@Transactional
	public Integer gettingHotedId(String dataincity, String datainhotel) {
		// TODO Auto-generated method stub
		return bookingDao.gettingHotedId(dataincity, datainhotel);
	}

	@Override
	@Transactional
	public Integer callStoredProcedure(Date fromDate, Date toDate, String bookedHotelId, int neededRooms) {
		// TODO Auto-generated method stub
		return bookingDao.callStoredProcedure(fromDate, toDate, bookedHotelId, neededRooms);
	}

	@Override
	@Transactional
	public Integer gettingPricePerHotel(String dataincity, String datainhotel) {
		// TODO Auto-generated method stub
		return bookingDao.gettingPricePerHotel(dataincity, datainhotel);
	}

}
