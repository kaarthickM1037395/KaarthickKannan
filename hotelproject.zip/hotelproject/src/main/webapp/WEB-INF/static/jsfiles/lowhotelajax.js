function populate()
{
	var cityData=document.getElementById("CityOfHotel").value;

	$.ajax({ 
        url: "ajaxforgettinglowpricehotels",
        data: {'citForLow':cityData},
        success: function(response) {
        		//document.getElementById("hotel").options.remove();
        		var datalow=response.split("+");
        		var opt;
        		document.getElementById("nameOfHotel").options.length = 1;
        		for(var i=0;i<(datalow.length);i++)
        			{
        				opt=new Option(datalow[i]);
        				
        				document.getElementById("nameOfHotel").options.add(opt);
        			}
            },
            error:function(){
            }})

}