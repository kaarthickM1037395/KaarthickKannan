function gethotelid()
{
	 //getpriceperhotel();

	var dataInCity=document.getElementById("city").value;
	var dataInHotel=document.getElementById("hotel").value;
	$.ajax({ 
        url: "ajaxforgettinghotelId",
        data: {'dataincity':dataInCity,'datainhotel':dataInHotel},
        success: function(response) {
        		//document.getElementById("hotel").options.remove();
        	
        	var dataa=response.split("-");
        	var opt;
        	var opt2;
        	
        	for(var i=0;i<(dataa.length);i++)
			{
        		if(i==0)
        			{
        opt=dataa[i];
        			}
        		else
        			{
        		
        			
        			opt2 =dataa[i];
        			}
			}
    		
    		var grandTotal=document.getElementById("totalPrice").value;
    		
    	
        				document.getElementById("hotelId").value=+opt;
        		   document.getElementById("priceperday").value=+opt2;	
        
        			if(grandTotal!=0)
        				{
        				document.getElementById("noDays").value=0;
        				document.getElementById("totalPrice").value=0;
        			alert("please click GET GRAND TOTAL to get the price for room you have booked");
        				}
        			
        		   
            },  
            error:function(){
            alert("error");
            }})
            
          
}

function handleExc()
{
	document.getElementById("totalPrice").value=0;
}

