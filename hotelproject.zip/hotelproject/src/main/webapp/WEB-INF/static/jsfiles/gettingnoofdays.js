function getNoOfDays()
{
	
	var fromdate=document.getElementById("dt1").value;
	var todate=document.getElementById("dt2").value;
	
	
	var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
	var firstDate = new Date(fromdate);
	var secondDate = new Date(todate);

	var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime())/(oneDay)));
	
	
	var diffDay=diffDays+1;
	document.getElementById("noDays").value=diffDay;
	
	var priceperday=document.getElementById("priceperday").value;
	
	var noOfRooms=document.getElementById("myNumber").value;
	
	var grandTotal=(priceperday*diffDay*noOfRooms);
	
	document.getElementById("totalPrice").value=grandTotal;
	
	if((firstDate > secondDate) || (fromdate > todate))
	{
	document.getElementById("noDays").value=0;
	}
	
}