function populateHotels()
{

	var cityData=document.getElementById("city").value;
	$.ajax({ 
        url: "ajaxforgettinghotels",
        data: {'cit':cityData},
        success: function(response) {
        		//document.getElementById("hotel").options.remove();
        		var data=response.split("-");
        		var opt;
        		document.getElementById("hotel").options.length =1;
        		for(var i=0;i<(data.length);i++)
        			{
        				opt=new Option(data[i]);
     				
        				document.getElementById("hotel").options.add(opt);
        			}
            },
            error:function(){
            	
            	alert("error");
            }})

}