package com.mindtree.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.mindtree.pojo.BookingDetails;
import com.mindtree.service.BookingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class ManagementControllerTest {

	@Configuration

	static class TestConfiguration {
		@Bean
		public BookingService bookingService() {
			return Mockito.mock(BookingService.class);
		}

		@Bean
		public ManagementController managementController() {
			return new ManagementController();
		}
	}

	@Autowired
	private BookingService bookingService;

	@Autowired
	private ManagementController managementController;

	private MockMvc mockMvc;

	@Test
	public void bookRoom() throws Exception {

		mockMvc.perform(get("/bookrooms")).andExpect(status().isOk())
				.andExpect(forwardedUrl("/WEB-INF/view/bookroom.jsp"));

	}

	@Test
	public void thankYouTest() throws Exception {

		mockMvc.perform(get("/Thankyou")).andExpect(status().isOk())
				.andExpect(forwardedUrl("/WEB-INF/view/Thanks.jsp"));
	}

	@Test
	public void viewLowTest() throws Exception {
		mockMvc.perform(get("/viewlow")).andExpect(status().isOk())
				.andExpect(forwardedUrl("/WEB-INF/view/viewfivelow.jsp"));
	}

	@Before
	public void setup() {
		BookingDetails book;
		mockMvc = MockMvcBuilders.standaloneSetup(this.managementController).setViewResolvers(viewResolver()).build();

	}

	public ViewResolver viewResolver() {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();

		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/view/");
		viewResolver.setSuffix(".jsp");

		return viewResolver;
	}

}
